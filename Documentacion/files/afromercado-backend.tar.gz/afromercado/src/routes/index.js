// Enrutador principal — agrupa todas las rutas de la API
const express = require("express");
const authRoutes = require("./auth.routes");

const router = express.Router();

router.get("/", (req, res) => {
  res.json({ ok: true, mensaje: "API de AfroMercado 🌿", version: "1.0.0-mvp" });
});

router.use("/auth", authRoutes);
// Aquí se irán sumando: /productos, /pedidos, /pagos, /entregas

module.exports = router;
