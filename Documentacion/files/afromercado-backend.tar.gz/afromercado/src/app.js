// ============================================================
//  AfroMercado API — Aplicación Express
// ============================================================
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rutas = require("./routes");
const { manejadorErrores, rutaNoEncontrada } = require("./middlewares/errores");

const app = express();

// Seguridad y middlewares base
app.use(helmet());                          // cabeceras de seguridad
app.use(cors());                            // permite peticiones del frontend
app.use(express.json());                    // parsea JSON del body
app.use(express.urlencoded({ extended: true }));

// Rutas de la API
app.use("/api", rutas);

// Manejo de rutas no encontradas y errores (siempre al final)
app.use(rutaNoEncontrada);
app.use(manejadorErrores);

module.exports = app;
